# CS300

    What was the problem you were solving in the projects for this course?

How to implement various data structures and algorithms.

    How did you approach the problem? Consider why data structures are important to understand.

By following instruction and implementing the data structures and algorithhms taught by this course. These topics are important because they give us ways to navigate information in a useful way.
    
    How did you overcome any roadblocks you encountered while going through the activities or project?

Thorough research and re-reading the text.

    How has your work on this project expanded your approach to designing software and developing programs?

i have more of an idea of how to make data structures and parse through information, which will be invaluable in the future when developing programs/ software.

    How has your work on this project evolved the way you write programs that are maintainable, readable, and adaptable?

When it comes to maintainability and readability, documentation is key. Being able to make thorough comments, and describe what youre doing so that anyone in the future who looks at my code can understand what is going on has been important to my growing skill as a developer.
    
