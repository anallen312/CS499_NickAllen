# CS255


    Briefly summarize the DriverPass project. Who was the client? What type of system did they want you to design?

    

For driverpass, the client was a driving school. They wanted a system designed that would help their students pass their driving tests easier by implementing practice tests, trackable progress reports, and easily updated DMV policies and regulations.
    

    If you could choose one part of your work on these documents to revise, what would you pick? How would you improve it?


The work I would revise would be the short paper included with project one. I "missed the mark" by not understanding what the prompt was asking when it asked me how I would apply a process modeling approach to the driverpass project. To improve it, I would describe the processes and subprocesses included in the project.


    How did you interpret the user’s needs and implement them into your system design? Why is it so important to consider the user’s needs when designing?


A wide variety of people from many different backgrounds will be accessing this system to help them earn their driver's license, so my goal was to make the system as accessible as possible to as broad a range of technology as possible. It's important to consider needs like this when designing systems so all the users are able to use the system to its full potential.


    How do you approach designing software? What techniques or strategies would you use in the future to analyze and design a system?

    
This is an extremely open-ended question, so I am going to respond equally as open-ended. In the future, I will design a system by keeping the users' needs in mind while also fulfilling the expectations of the client, adhering to their budgetary, staffing, and expectational concerns.
