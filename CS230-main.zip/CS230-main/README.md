# CS230
Design Doc Q&A

1. Briefly summarize The Gaming Room client and their software requirements. Who was the client? What type of software did they want you to design?

Draw It or Lose It is a web-based game application based on the classic TV game, Win, Lose or Draw. Our aim is to create an entertaining game that lets teams compete against each other and the clock, trying to guess phrases, titles, or things from images that are drawn.

2. What did you do particularly well in developing this documentation?

I did well verbalizing the design constraints and requirements for this specific application.

3. What about the process of working through a design document did you find helpful when developing the code?

I understand and appreciate how it gets all of your ducks in a row when beginning a project. when youre thinking of the major aspects of the design, and lay them out on paper, its easier to break what you need to do to complete it into small pieces.

4. If you could choose one part of your work on these documents to revise, what would you pick? How would you improve it?

Somehow I forgot to include the development tools part in the requirements section, although I do remember doing it. I think I sent an earlier save of the document by mistake, so I would add that back in.

5. How did you interpret the user’s needs and implement them into your software design? Why is it so important to consider the user’s needs when designing?

The end goal of most software is for it to be easily accessed and used by real people. If it is not useable to you target demographic, its essentially useless.

6. How did you approach designing software? What techniques or strategies would you use in the future to analyze and design a similar software application?

I approached this process step-by-step. If you outline what the contraints are, you can then isolate the requirements that will work to complete the project. Doing it this way and the way the document outlines gives a good design process that builds on each previous step.
